<?php

namespace App\Interfaces;

interface IValidationParams {
    public static function ValidationParams() : array;
}