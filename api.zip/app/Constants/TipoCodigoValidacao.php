<?php

namespace App\Constants;

enum TipoCodigoValidacao: string {
    case REDEFINIR_SENHA = "1d02c1cf-2ad3-4fa7-aed7-830e39657aa1";
    case CONFIRMAR_CONTA = "eb3bcec4-252c-4404-99c4-0a7e5d02b6c6";
}