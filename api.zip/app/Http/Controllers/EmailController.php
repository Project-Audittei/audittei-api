<?php

namespace App\Http\Controllers;

use App\Mail\EmailValidacaoConta;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class EmailController extends Controller
{
    public static function EnviarEmailConfirmacaoConta(User $usuario, string $hash) {
        Mail::to($usuario->email)->send(new EmailValidacaoConta($usuario->nomeCompleto, $hash));
        
        return true;
    }
}
